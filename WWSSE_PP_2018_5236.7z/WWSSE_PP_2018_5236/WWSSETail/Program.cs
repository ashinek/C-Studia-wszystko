﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WWSSETail
{
    class Program
    {
        static void Main(string[] args)
        {
            int iloscLinii = 5;
            string[] buforLinii = new string[iloscLinii];
            int pozycjaOstatniej = -1;
            string liniaTekstu ="";
            while (liniaTekstu != null)
            {
                liniaTekstu = Console.ReadLine();
                if (liniaTekstu != null)
                {
                    pozycjaOstatniej = (pozycjaOstatniej + 1) % iloscLinii;
                    buforLinii[pozycjaOstatniej] = liniaTekstu;
                }
            }
            for (int k = 0; k < iloscLinii;k++ )
            {
                pozycjaOstatniej = (pozycjaOstatniej + 1) % iloscLinii;
                if (buforLinii[pozycjaOstatniej] != null)
                {
                    Console.WriteLine(buforLinii[pozycjaOstatniej]);
                }
            }

        }
    }
}
